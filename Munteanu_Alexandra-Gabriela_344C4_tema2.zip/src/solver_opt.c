/*
 * Tema 2 ASC
 * 2023 Spring
 */
#include "utils.h"

/*
 * Add your optimized implementation here
 */

// functia care calculeaza transpusa unei matrici
extern inline double *matrix_transpose(register double *A, register int N) {
	// aloc memorie pentru transpusa
	register double *trans = calloc(N * N, sizeof(double));
	register int i, j;
	
	// calculez transpusa cu ajutorul pointer-ilor
	for (i = 0; i < N; i++) {
        	double *s = &A[i * N];
        	double *d = &trans[i];
        	for (j = 0; j < N; j++) {
            		*d = *s;
            		s++;
            		d += N;
        	}
    	}

	//returnez transpusa matricii
        return trans;
}

// functia care calculeaza inmultirea unei matrici cu o matrice superior triunghiulara
extern inline double *multiplication_with_upper_triangular_matrix(register double* A, register double* B, register int N) {
	// aloc memorie pentru rezultatul inmultirii
	register double* result = calloc(N * N, sizeof(double));
    	register int i, j, k;

	// parcurg matricile
	for (i = 0; i < N; i++) {
        	for (k = 0; k < N; k++) {
			// initializez cu 0 rezultatul
            		result[i * N + k] = 0;

			for (j = i; j < N; j++) {
				// calculez inmultirea celor 2 matrici
                		result[i * N + k] += A[i * N + j] * B[j * N + k];
            		}
        	}
    	}

	// returnez rezultatul obtinut
	return result;
}

// functia care calculeaza inmultirea unei matrici cu o matrice inferior triunghiulara
extern inline double *multiplication_with_lower_triangular_matrix(register double* A, register double* B, register int N) {
	register int i, j, k;
	// aloc memorie pentru rezultatul inmultirii
        register double *result = calloc(N * N, sizeof(double));

	// parcurg matricile
        for (i = 0; i < N; i++) {
                for (k = 0; k < N; k++) {
			register double a = A[i * N + k];
                        for (j = 0; j <= k; j++) {
				// realizez inmultirea celor 2 matrici
                                result[i * N + j] += a * B[k * N + j];
                        }
                }
        }

	// returnez rezultatul obtinut
        return result;
}

// functia care calculeaza inmultirea a 2 matrici obisnuite
extern inline double* multiplication(register double *A, register double *B, register int N) {
	register int i, j, k;
	// aloc memorie pentru rezultatul inmultirii
        register double *result = calloc(N * N, sizeof(double));
	
	// parcurg cele 2 matrici
	for (i = 0; i < N; i++) {
        	for (k = 0; k < N; k++) {
			// salvez variabila a pentru a nu fi incarcata la fiecare iteratie viitoare
            		register double a = A[i * N + k];

            		for (j = 0; j < N; j++) {
				// realizez inmultirea celor 2 matrici
                		result[i * N + j] += a * B[k * N + j];
            		}
        	}
    	}

	// returnez rezultatul obtinut
        return result;
}

// functia care calculeaza suma a 2 matrici
extern inline double *add_matrix(register double* destination_matrix, register double* source_matrix, register int N) {
	register int i, j;

	for (i = 0; i < N; i++) {
		// salvez indexul
        	unsigned int index = i * N;
		// iau elementul corespunzator de la indexul curent din cele 2 matrici ce trebuie adunate
        	double *s = &source_matrix[index];
        	double *d = &destination_matrix[index];
        
		for (j = 0; j < N; j++) {
			// adun cele 2 elemente
            		*d += *s;
			// trec la urmatorul element la ambele matrici
            		d++;
            		s++;
        	}
    	}

	// returnez suma obtinuta
    	return destination_matrix;
}

double* my_solver(register int N, register double *A, register double* B) {
	// aloc memorie pentru toate variabilele de care voi avea nevoie
        register double* A_trans = calloc(N * N, sizeof(double));
        register double* B_trans = calloc(N * N, sizeof(double));
        register double* AB = calloc(N * N, sizeof(double));
        register double* ABA = calloc(N * N, sizeof(double));
        register double* BB = calloc(N * N, sizeof(double));

	// calculez transpusele celor 2 matrici
        A_trans = matrix_transpose(A, N);
        B_trans = matrix_transpose(B, N);

	// efectuez calculul ecuatiei folosind functiile implementate anterior
	// calculez A x B
        AB = multiplication_with_upper_triangular_matrix(A, B, N);
	// calculez A x B x A_t, unde A_t este transpusa matricii A
        ABA = multiplication_with_lower_triangular_matrix(AB, A_trans, N);
	// calculez B_t x B_t, unde B_t este transpusa matricii B
	BB = multiplication(B_trans, B_trans, N);
	// calculez suma celor 2 parti ale ecuatiei pentru a obtine rezultatul final
	add_matrix(ABA, BB, N);

	// eliberez memoria alocata
	free(AB);
    	free(A_trans);
    	free(B_trans);
    	free(BB);
    	
	// returnez rezultatul final al ecuatiei
        return ABA;
}
