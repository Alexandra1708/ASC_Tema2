/*
 * Tema 2 ASC
 * 2023 Spring
 */
#include "utils.h"
#include "cblas.h"
#include <string.h>
#include <stdio.h>

/* 
 * Add your BLAS implementation here
 */
double* my_solver(int N, double *A, double *B) {
	// aloc memorie pentru vectorii de care voi avea nevoie in continuare
	double* B_copy = calloc(N * N, sizeof(double));
	double* result = calloc(N * N, sizeof(double));
	int i;

	// copiez matricea B pentru a o folosi la apelarea urmatoarelor functii din biblioteca cblas
    	for (i = 0; i < N * N; i++) {
        	B_copy[i] = B[i];
    	}

	// calculez B = A * B_initial
    	cblas_dtrmm(CblasRowMajor, CblasLeft, CblasUpper, CblasNoTrans, CblasNonUnit, N, N, 1.0, A, N, B, N);
	// calculez B = B * A_t (unde B = A * B, calculat anterior, si A_t = transpusa matricei A) 
	cblas_dtrmm(CblasRowMajor, CblasRight, CblasUpper, CblasTrans, CblasNonUnit, N, N, 1.0, A, N, B, N);
	// calculez B = B_initial_t * B_initial_t + B, unde B este cel calculat la pasul 2
	cblas_dgemm(CblasRowMajor, CblasTrans, CblasTrans, N, N, N, 1.0, B_copy, N, B_copy, N, 1.0, B, N);
	
	// copiez rezultatul ecuatiei intr-un alt vector
    	for (i = 0; i < N * N; i++) {
        	result[i] = B[i];
    	}
    
	// eliberez memoria alocata pentru copia lui B_initial
    	free(B_copy);

	// returnez rezultatul final al ecuatiei date
	return result;
}
