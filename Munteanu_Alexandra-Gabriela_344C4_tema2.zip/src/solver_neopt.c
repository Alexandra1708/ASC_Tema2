/*
 * Tema 2 ASC
 * 2023 Spring
 */
#include "utils.h"

/*
 * Add your unoptimized implementation here
 */

// functia care calculeaza transpusa unei matrici
double* matrix_transpose(double *A, int N) {
	// aloc memorie pentru transpusa
	double *trans = calloc(N * N, sizeof(double));
	int i, j;

	// parcurg matricea
	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			// transpun matricea A
			trans[i * N + j] = A[j * N + i];
		}
	}

	// returnez matricea transpusa
	return trans;
}

// functia care calculeaza inmultirea unei matrici cu o matrice superior triunghiulara
// in parametri, am considerat ca A este matricea superior triunghiulara
double *multiplication_with_upper_triangular_matrix(double *A, double *B, int N) {
	int i, j, k;
	// aloc memorie pentru rezultatul inmultirii
	double *result = calloc(N * N, sizeof(double));
	// parcurg matricile 
	for (i = 0; i < N; i++) {
        	for (j = 0; j < N; j++) {
			result[i * N + j] = 0;
			// parcurg elementele din A de deasupra diagonalei principale
			// (celelalte fiind egale cu 0)
            		for (k = i; k < N; k++) {
				// realizez inmultirea celor 2 matrice
				result[i * N + j] += A[i * N + k] * B[k * N + j];
            		}
        	}
    	}

	// returnez rezultatul obtinut
	return result;
}

// functia care calculeaza inmultirea unei matrici cu o matrice inferior triunghiulara
// in parametri, am considerat ca B este matricea inferior triunghiulara
double *multiplication_with_lower_triangular_matrix(double *A, double *B, int N) {
	int i, j, k;
	// aloc memorie pentru rezultatul inmultirii
	double *result = calloc(N * N, sizeof(double));
	
	// initializez rezultatul cu 0
	for (i = 0; i < N * N; i++) {
		result[i] = 0.0;
	}

	// parcurg matricile
	for (i = 0; i < N; i++) {
        	for (j = 0; j < N; j++) {
			// iterez prin elementele de sub diagonala principala
			// (celelalte fiind egale cu 0)
            		for (k = j; k < N; k++) {
				// realizez inmultirea celor 2 matrice
				result[i * N + j] += A[i * N + k] * B[k * N + j];
            		}
        	}
    	}

	// returnez rezultatul obtinut
	return result;
}

// functia care calculeaza inmultirea a 2 matrici oarecare
double* multiplication(double *A, double *B, int N) {
	int i, j, k;
	// aloc memorie pentru rezultatul inmultirii
	double *result = calloc(N * N, sizeof(double));

	// iterez prin elementele celor 2 matrici
	for (i = 0; i < N; i++) {
        	for (j = 0; j < N; j++) {
            		result[i * N + j] = 0;

            		for (k = 0; k < N; k++) {
				// realizez inmultirea lor
                		result[i * N + j] += A[i * N + k] * B[k * N + j];
            		}
        	}
    	}

	// returnez rezultatul obtinut
	return result;
}

double* my_solver(int N, double *A, double* B) {
	int i, j;
	// aloc memorie pentru toate variabilele de care voi avea nevoie
	double* A_trans = calloc(N * N, sizeof(double));
	double* B_trans = calloc(N * N, sizeof(double));
	double* AB = calloc(N * N, sizeof(double));
	double* ABA = calloc(N * N, sizeof(double));
	double* BB = calloc(N * N, sizeof(double));
	double* result = calloc(N * N, sizeof(double));

	// calculez transpusele celor 2 matrici
	A_trans = matrix_transpose(A, N);
	B_trans = matrix_transpose(B, N);

	// calculez A x B
	AB = multiplication_with_upper_triangular_matrix(A, B, N);
	// calculez A x B x A_t, unde A_t este transpusa matricii A
	ABA = multiplication_with_lower_triangular_matrix(AB, A_trans, N);
	// calculez B_t x B_t, unde B_t este transpusa matricii B
	BB = multiplication(B_trans, B_trans, N);

	// parcurg elementele matricilor
	for (i = 0; i < N; i++) {
        	for (j = 0; j < N; j++) {
			// adun element cu element cele 2 parti calculate anterior
            		result[i * N + j] = ABA[i * N + j] + BB[i * N + j];
        	}
   	}

	free(A_trans);
	free(B_trans);
	free(AB);
	free(BB);
	free(ABA);

	// returnez rezultatul obtinut
	return result;
}
