import matplotlib.pyplot as plt

N = [200, 400, 600, 800, 1200, 1500]
blas_times = [0.0068, 0.0390, 0.1304, 0.2844, 0.9330, 1.8199]
neopt_times = [0.1326, 1.1545, 3.9992, 9.7512, 31.8406, 75.0238]
opt_m_times = [0.0598, 0.4761, 1.6179, 3.7983, 12.6944, 28.1032]

fig, ax = plt.subplots()
ax.plot(N, blas_times)
ax.set(xlabel='N', ylabel='timp rulare (s)',
       title='Timpi de rulare pentru Blas')
ax.grid()
fig.savefig("blas.png")
plt.show()

fig, ax = plt.subplots()
ax.plot(N, neopt_times)
ax.set(xlabel='N', ylabel='timp rulare (s)',
       title='Timpi de rulare pentru Neopt')
ax.grid()
fig.savefig("neopt.png")
plt.show()

fig, ax = plt.subplots()
ax.plot(N, opt_m_times)
ax.set(xlabel='N', ylabel='timp rulare (s)',
       title='Timpi de rulare pentru Opt_m')
ax.grid()
fig.savefig("opt_m.png")
plt.show()
